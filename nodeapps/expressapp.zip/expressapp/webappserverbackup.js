//1.load express

var express = require('express');

//1a. load the path module. this will be used by static middleware of express. the path is standard node module
var path = require('path');

//1b import the data module
var dataModel = require('./datamodel');
//1c. load the body-parser
var bodyParser = require("body-parser");
//1d. loading mongoose driver
var mongoose = require('mongoose');
//1e. set the globalpromise to manage all async call madeby application using mongoose driver
mongoose.Promise = global.Promise;

//2. define an instance of express
var instance = express();

//3. configure all middlewares, call "use()" method on express instance
//3a. static files
instance.use(express.static(path.join(__dirname, './../node_modules/jquery/dist/')));
//3b. dfine express-router for seggrigating urls for html page web requests and rest api requests

var router = express.Router();

//3c. add the router object in the express middleware
instance.use(router);
//3d. configure the body-parser middleware
//3d.1 use urlencoded as false to read data from http url as querystring, formmodel etc.
instance.use(bodyParser.urlencoded({ extended: false }));
//3d.2 use the json() parser for body parser
instance.use(bodyParser.json());
//4. create a web request handlers
//4a. this will return home.html from views folder
router.get("/home", function (req, res) {
    res.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    });
});

//5. Model-schema-mapping with collection on Mongo DB and esablishing connection with it.
mongoose.connect(
    "mongodb://localhost/ProductsAppDb",
    { useNewUrlParser: true }
);

//5a. get the connection object
//if dbConnect is not undefined then connection is successful
var dbConnect = mongoose.connection;
if (!dbConnect) {
    console.log("Sorry connection failed with db");
    return;
}

//5b. define schema (recommended to have same attributes as per the collection)
var productsSchema = mongoose.Schema({
    ProductId: Number,
    ProductName: String,
    CategoryName: String,
    manufacturer: String,
    price: Number
});

//5c. map the schema with the collection
//                                  name     schema         collection
var productModel = mongoose.model("Products", productsSchema, "Products");

//6. create rest api request handlers 
instance.get("/api/products", function (request, response) {
    //5a. read header for authoriazation values
    var authValues = request.headers.authorization;
    // console.log("auth",authValues);
    var credentials = authValues.split("n")[1];
    var data = credentials.split(":");
    var username = data[0];
    var password = data[1];
    console.log("username", username);
    console.log("password", password);
    if (username == "shweta" && password == "shweta") {
        response.send(JSON.stringify(dataModel.getData()));
    } else {
        response.statusCode = 401;
        response.end({
            status: response.statusCode,
            message: "Unauthorize access"
        })
    }

})

instance.post("/api/products", function (request, response) {
    var data = request.body; //read the request body
    console.log(data);
    var responseData = dataModel.addData(data);
    response.send(JSON.stringify(responseData));
})
instance.get("/api/products/:id", function (request, response) {
    //use "params" property of request object to read url parameter 
    var id = request.params.id;
    console.log("Received id", id);
    var record = dataModel.getData().filter(function (v, idx) {
        return v.id == id;
    });
    response.send(JSON.stringify(record));
});

instance.put("/api/products", function (request, response) {
    var data = request.body;
    console.log(data);
    var responseData = dataModel.updateData(data);
    console.log(responseData);
    response.send(JSON.stringify(responseData));
});

instance.delete("/api/products/:id", function (request, response) {
    var id = request.params.id;
    console.log("Id is", id);
    var records = dataModel.deleteData(id);
    response.send(JSON.stringify(records));
})

//6. start listening
instance.listen(4070, function () {
    console.log("Server started on 4070..");
})
