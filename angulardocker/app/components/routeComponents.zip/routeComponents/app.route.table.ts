import { RouterModule, Routes, Route } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";
import { HomeComponent } from './app.home.component';
import { ContactComponent } from './app.contact.component';
import { AboutComponent } from './app.about.component';
import { ProductComponent } from "../productcomponent/app.product.component";

//define route table
const routes: Routes = [
    { path: " ", component: HomeComponent },
    { path: "about/:id", component: AboutComponent },
    {
        path: "contact", component: ContactComponent, children: [{
            path: "product", component: ProductComponent
        }]
    }
];

//register the route table for root of the current angular app
// when routing i provided to import of ngModule this will load RouterModule with route table
export const routing: ModuleWithProviders = RouterModule.forRoot(routes); 